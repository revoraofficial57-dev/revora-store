# Ready-to-Deploy Store Template

This is a clean, multi-feature e-commerce store template ready to be deployed or imported into Google AI Studio. All previous personal contact details, emails, and passwords have been removed and replaced with standard placeholders.

---

## 🔑 Default Admin Panel Credentials
When accessing the Admin Dashboard in this new store:
- **Username**: `admin@store` (or `admin`)
- **Password**: `AdminPassword@123` (or `admin123`)

---

## 🛠️ How to Customize for Your Client / New Store

### 1. Store Name, Contact & Bank Account
Open `src/data/initialData.ts`:
- Change `storeName` and `tagline` to your client's brand.
- Set `supportEmail` (e.g. `client@gmail.com`).
- Set `whatsappNumber` and `supportPhone` (e.g. `+92 300 1234567`).
- Update `bankAccounts` with their Bank Name, Account Title, and IBAN for direct bank transfers.

### 2. Products, Categories & Pricing
In `src/data/initialData.ts`:
- Replace `INITIAL_CATEGORIES`, `INITIAL_PRODUCTS`, and `INITIAL_DESIGNS` with your client's product catalog.
- Set prices, sizes, stock levels, and allowed payment methods.

### 3. Theme & Colors
- **Accent Color**: Search for `bg-emerald-600` or `emerald` classes and replace with your client's primary brand color (e.g., `blue`, `indigo`, `amber`, `black`).
- **Typography & Meta**: Update `index.html` and `metadata.json` with the new store title, meta description, and fonts.

### 4. Running Locally
```bash
npm install
npm run dev
```
Open `http://localhost:3000` to preview.
